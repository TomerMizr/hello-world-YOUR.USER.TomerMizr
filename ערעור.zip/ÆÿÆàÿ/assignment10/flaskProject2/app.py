from flask import Flask, render_template, request, session,redirect

app = Flask(__name__)
app.secret_key = 'as123'

@app.route('/')
def about():
    return render_template('about.html')

from pages.assignment10.assignment10 import assignment10
app.register_blueprint(assignment10)

@app.route('/CV-contact.html')
def ccContact():
    return render_template('CV-contact.html')


@app.route('/assignment8')
def assignment8():
    return render_template('assignment8.html', fullName={'firstName': 'Tomer', 'lastName': 'Mizrahi'},
                           hobbies={'gaming', 'swiming', 'camping'})


@app.route('/assignment9', methods=['GET', 'POST'])
def assignment9():
    users = [{"id": 7, "email": "michael.lawson@reqres.in", "first_name": "Michael", "last_name": "Lawson",
              "avatar": "https://reqres.in/img/faces/7-image.jpg"},
             {"id": 8, "email": "lindsay.ferguson@reqres.in", "first_name": "Lindsay", "last_name": "Ferguson",
              "avatar": "https://reqres.in/img/faces/8-image.jpg"},
             {"id": 9, "email": "tobias.funke@reqres.in", "first_name": "Tobias", "last_name": "Funke",
              "avatar": "https://reqres.in/img/faces/9-image.jpg"},
             {"id": 10, "email": "byron.fields@reqres.in", "first_name": "Byron", "last_name": "Fields",
              "avatar": "https://reqres.in/img/faces/10-image.jpg"},
             {"id": 11, "email": "george.edwards@reqres.in", "first_name": "George", "last_name": "Edwards",
              "avatar": "https://reqres.in/img/faces/11-image.jpg"},
             {"id": 12, "email": "rachel.howell@reqres.in", "first_name": "Rachel", "last_name": "Howell",
              "avatar": "https://reqres.in/img/faces/12-image.jpg"}]

    if request.method == "GET":
        if 'name' in request.args:
            UserName = request.args['name']
            return render_template('assignment9.html', users=users, UserName=UserName,flag=True)
    flag =True
    if request.method == "POST":
            username = request.form['name']
            session['logged_in']=True
            session['name']=username
            return render_template('assignment9.html', users=users, username=username, flag=False)
    return render_template('assignment9.html',flag=flag)

@app.route('/logged_out')
def out():
    session['logged_in'] = False
    return redirect('/assignment9')




if __name__ == '__main__':
    app.run(debug=True)

