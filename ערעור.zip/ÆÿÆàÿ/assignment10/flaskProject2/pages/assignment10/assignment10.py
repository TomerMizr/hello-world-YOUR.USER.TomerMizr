from flask import Blueprint
from flask import Flask, url_for, redirect, render_template
from flask import request, session
import mysql.connector





assignment10 = Blueprint('assignment10', __name__, static_folder='static',
                         static_url_path="/assignment10",
                         template_folder='templates')

@assignment10.route('/assignment10', methods=['GET', 'POST'])
def assignment10_func():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        query = "INSERT INTO users(first_name,last_name,email) VALUES ('%s','%s','%s')" % (first_name, last_name, email)
        return_values = interact_db(query, 'commit')
        requestQuery = "SELECT * FROM users where email='%s'" % email
        back_U = interact_db(requestQuery, 'fetch')
        new_list_Q = "SELECT * FROM users"
        new_list = interact_db(new_list_Q, 'fetch')

        return render_template('assignment10.html', back_U=back_U, users=new_list)
    else:
        query = "SELECT * FROM users"
        query_result = interact_db(query, 'fetch')
        return render_template('assignment10.html', users=query_result)


@assignment10.route('/assignment10/deletion', methods=['GET', 'POST'])
def assignment10Delete_func():

    if request.method == 'GET':
        id = request.args['id']
        query = "DELETE FROM users WHERE id='%s';" % id
        interact_db(query, query_type='commit')
    return redirect('/assignment10')

@assignment10.route('/assignment10/update', methods=['GET', 'POST'])
def assignment10Update_func():

    if request.method == 'POST':
        id = request.form['id']

        setQuery = ""

        for key in request.form:
           value = request.form[key]
           if key != 'id' and value != '':
               setQuery += key + "='" + value + "' ,"

        setQuery = setQuery[:-1]

        query = "UPDATE users SET " + setQuery + " WHERE id='%s';" % id
        interact_db(query, query_type='commit')

    return redirect('/assignment10')

def interact_db(query, query_type: str):
    return_value = False
    connection = mysql.connector.connect(host='localhost', user='root', passwd='1234', database='assignment10')
    cursor = connection.cursor(named_tuple=True)
    cursor.execute(query)

    if query_type == 'commit':
        connection.commit()
    return_value = True

    if query_type == 'fetch':
        query_result= cursor.fetchall()
        return_value = query_result

    connection.close()
    cursor.close()
    return return_value


